import requests
from bs4 import BeautifulSoup

BASE_URL = "https://www.gledaitv.fan/"

HEADERS = {
    "User-Agent": "Mozilla/5.0"
}

def get_categories():
    r = requests.get(BASE_URL, headers=HEADERS, timeout=10)
    r.raise_for_status()

    soup = BeautifulSoup(r.text, "html.parser")

    categories = []

    for a in soup.select("ul.list.after li a"):
        name = a.contents[0].strip()
        url = a.get("href")

        categories.append({
            "name": name,
            "url": url
        })

    return categories
