import sys
import xbmcplugin
import xbmcgui

from resources.lib.scraper import get_categories

HANDLE = int(sys.argv[1])

def show_categories():
    categories = get_categories()

    for cat in categories:
        li = xbmcgui.ListItem(label=cat["name"])

        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=cat["url"],
            listitem=li,
            isFolder=True
        )

    xbmcplugin.endOfDirectory(HANDLE)


if __name__ == "__main__":
    show_categories()
